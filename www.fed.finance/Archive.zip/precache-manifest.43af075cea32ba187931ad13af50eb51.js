self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "766f00343ba17602d8a5ec57eaf3eeb9",
    "url": "./index.html"
  },
  {
    "revision": "0ea43f1ad347d346423a",
    "url": "./static/css/4.f04942fe.chunk.css"
  },
  {
    "revision": "b3bb5fef9d2a2d414dd5",
    "url": "./static/js/0.287d0e93.chunk.js"
  },
  {
    "revision": "ac7a067af2530e32bf70",
    "url": "./static/js/1.9d651c71.chunk.js"
  },
  {
    "revision": "0ea43f1ad347d346423a",
    "url": "./static/js/4.1c36bd39.chunk.js"
  },
  {
    "revision": "06da92ab0204d35d374fc3edc3914b99",
    "url": "./static/js/4.1c36bd39.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a97fddaa6de8cdac0b01",
    "url": "./static/js/5.568ef2df.chunk.js"
  },
  {
    "revision": "caaa9c24a9c77eaead93960f555b5a26",
    "url": "./static/js/5.568ef2df.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a47c17439adb23ee5ff0",
    "url": "./static/js/6.ac79ac4c.chunk.js"
  },
  {
    "revision": "002dd2eb241ecfa3ef43",
    "url": "./static/js/7.c241969a.chunk.js"
  },
  {
    "revision": "32bb1f262c64154d1b7f",
    "url": "./static/js/8.88cbe359.chunk.js"
  },
  {
    "revision": "e0060e6346fad15ce03d",
    "url": "./static/js/9.603e06fc.chunk.js"
  },
  {
    "revision": "ef998acd8f65ae6b9b420793d7484b0e",
    "url": "./static/js/9.603e06fc.chunk.js.LICENSE.txt"
  },
  {
    "revision": "b7c20d6ceb1247295456",
    "url": "./static/js/main.15bf08e6.chunk.js"
  },
  {
    "revision": "32a97e53cb6ba49eafa9",
    "url": "./static/js/runtime-main.f32b676c.js"
  },
  {
    "revision": "09f4068bb74fc78ffbce74f5596d6aa5",
    "url": "./static/media/Inter-Black.09f4068b.woff2"
  },
  {
    "revision": "e37354838bf8078ac0d296217613533f",
    "url": "./static/media/Inter-Black.e3735483.woff"
  },
  {
    "revision": "07e69b53f8cf91da94096d1abf484302",
    "url": "./static/media/Inter-BlackItalic.07e69b53.woff"
  },
  {
    "revision": "daa1ca3cebd42cf5ebd53d9a6942b2cf",
    "url": "./static/media/Inter-BlackItalic.daa1ca3c.woff2"
  },
  {
    "revision": "79260e5b693fac2ee373b659f01a2bdf",
    "url": "./static/media/Inter-Bold.79260e5b.woff"
  },
  {
    "revision": "aed27700d84e327fda56b4a427b03061",
    "url": "./static/media/Inter-Bold.aed27700.woff2"
  },
  {
    "revision": "8ef77a031c5b96e53f2eeeb009232181",
    "url": "./static/media/Inter-BoldItalic.8ef77a03.woff2"
  },
  {
    "revision": "e0879d64763e509f309940120e7d1f5a",
    "url": "./static/media/Inter-BoldItalic.e0879d64.woff"
  },
  {
    "revision": "38bc51bccb7dd07b2752c11888cbdc89",
    "url": "./static/media/Inter-ExtraBold.38bc51bc.woff"
  },
  {
    "revision": "92d16aee8fb5f5c5cfd660b2d07e1148",
    "url": "./static/media/Inter-ExtraBold.92d16aee.woff2"
  },
  {
    "revision": "0e4b21ebad8d568078450713ee9339cf",
    "url": "./static/media/Inter-ExtraBoldItalic.0e4b21eb.woff"
  },
  {
    "revision": "57ea76d011f6fff8cb7013b783bad58e",
    "url": "./static/media/Inter-ExtraBoldItalic.57ea76d0.woff2"
  },
  {
    "revision": "4bd040df09ea4765148b5743b8493e5f",
    "url": "./static/media/Inter-ExtraLight.4bd040df.woff"
  },
  {
    "revision": "4d9f96f8504cd034ef7e5f25434ca550",
    "url": "./static/media/Inter-ExtraLight.4d9f96f8.woff2"
  },
  {
    "revision": "54d3d9a59ea904ebd11c3ac308893bfb",
    "url": "./static/media/Inter-ExtraLightItalic.54d3d9a5.woff2"
  },
  {
    "revision": "84c26656e02913a54131fc64431212ae",
    "url": "./static/media/Inter-ExtraLightItalic.84c26656.woff"
  },
  {
    "revision": "9528384cf7aebfa81a198626cb05f5e8",
    "url": "./static/media/Inter-Italic.9528384c.woff2"
  },
  {
    "revision": "e4ad3666e223c64e4df963cec740bf09",
    "url": "./static/media/Inter-Italic.e4ad3666.woff"
  },
  {
    "revision": "5baca21acf845c8e746f08675f40300b",
    "url": "./static/media/Inter-Light.5baca21a.woff2"
  },
  {
    "revision": "b9920de0749addeb5a53462fb5bbe070",
    "url": "./static/media/Inter-Light.b9920de0.woff"
  },
  {
    "revision": "0555a46cda7fc3406a875d6bacf8fcff",
    "url": "./static/media/Inter-LightItalic.0555a46c.woff"
  },
  {
    "revision": "adc70179a9e60e14f2a4f7d106166004",
    "url": "./static/media/Inter-LightItalic.adc70179.woff2"
  },
  {
    "revision": "7a8cc7241f766a142e15b2948804e547",
    "url": "./static/media/Inter-Medium.7a8cc724.woff"
  },
  {
    "revision": "f6cf0a0bc5fce3307e2c426eb14eb752",
    "url": "./static/media/Inter-Medium.f6cf0a0b.woff2"
  },
  {
    "revision": "417907d2be56d39b2a9c0b52fc8a00e8",
    "url": "./static/media/Inter-MediumItalic.417907d2.woff"
  },
  {
    "revision": "565a7104c497ccb1bf12832d8b341861",
    "url": "./static/media/Inter-MediumItalic.565a7104.woff2"
  },
  {
    "revision": "4dd66a113d54a7f9a1ae913049610617",
    "url": "./static/media/Inter-Regular.4dd66a11.woff2"
  },
  {
    "revision": "7c539936c4c8c822b59a1bcc6c08a6ec",
    "url": "./static/media/Inter-Regular.7c539936.woff"
  },
  {
    "revision": "1db6c55ca0f2a97fbce3b0b3903a7bb7",
    "url": "./static/media/Inter-SemiBold.1db6c55c.woff"
  },
  {
    "revision": "dd8a55ef7058cdaeb96ef9fc65344726",
    "url": "./static/media/Inter-SemiBold.dd8a55ef.woff2"
  },
  {
    "revision": "81678d1a50a895cc1232f3e287976083",
    "url": "./static/media/Inter-SemiBoldItalic.81678d1a.woff"
  },
  {
    "revision": "ac201e30486307c75c5038f61df9fd9f",
    "url": "./static/media/Inter-SemiBoldItalic.ac201e30.woff2"
  },
  {
    "revision": "850febbe5e8a7625c5603061d2e7c0ce",
    "url": "./static/media/Inter-Thin.850febbe.woff2"
  },
  {
    "revision": "ead42837911f0b55b0877c12b50d9157",
    "url": "./static/media/Inter-Thin.ead42837.woff"
  },
  {
    "revision": "a76db06556290ed3bd198a72b24d8006",
    "url": "./static/media/Inter-ThinItalic.a76db065.woff"
  },
  {
    "revision": "e08d9b2a5079b81cc39804c2a7406254",
    "url": "./static/media/Inter-ThinItalic.e08d9b2a.woff2"
  },
  {
    "revision": "2690e3c25733fb852b55b3f8d651a431",
    "url": "./static/media/Inter-italic.var.2690e3c2.woff2"
  },
  {
    "revision": "90e8f61d26f65b5ff0acc45ddf6740ea",
    "url": "./static/media/Inter-roman.var.90e8f61d.woff2"
  },
  {
    "revision": "4b976905f2be1cb9201f5d94afd9edd2",
    "url": "./static/media/Inter.var.4b976905.woff2"
  },
  {
    "revision": "114fab910be089671a355764e2326334",
    "url": "./static/media/arrow-down-blue.114fab91.svg"
  },
  {
    "revision": "4d4a6a99f8bc24af0fcf805146d38a46",
    "url": "./static/media/arrow-down-grey.4d4a6a99.svg"
  },
  {
    "revision": "337ad716bd89163e2a9c3495b7e0f029",
    "url": "./static/media/arrow-right-white.337ad716.png"
  },
  {
    "revision": "e96d8158ff6d3087ab15e43e64fbb47e",
    "url": "./static/media/arrow-right.e96d8158.svg"
  },
  {
    "revision": "3de5556767e5ad43641b532a11b9da3e",
    "url": "./static/media/big_unicorn.3de55567.png"
  },
  {
    "revision": "e62a99c33b7eafddf701893750cedeb9",
    "url": "./static/media/blue-loader.e62a99c3.svg"
  },
  {
    "revision": "5dd950ec66be581e8da4376f49a19d77",
    "url": "./static/media/circle-grey.5dd950ec.svg"
  },
  {
    "revision": "716403ba670c3577abbea8e66f428721",
    "url": "./static/media/circle.716403ba.svg"
  },
  {
    "revision": "aa4c7a7647abc7ede02e017c1a0141b6",
    "url": "./static/media/coinbaseWalletIcon.aa4c7a76.svg"
  },
  {
    "revision": "80a3ae258c229f3c874a8acdf65adeea",
    "url": "./static/media/dropdown-blue.80a3ae25.svg"
  },
  {
    "revision": "50dbd07d8e7428d04464644f7cf819cf",
    "url": "./static/media/dropdown.50dbd07d.svg"
  },
  {
    "revision": "345dad7494f835eb9ae6c21c2d3a25f4",
    "url": "./static/media/dropup-blue.345dad74.svg"
  },
  {
    "revision": "50c67f3cdd04281013ef95e92fc7244e",
    "url": "./static/media/link.50c67f3c.svg"
  },
  {
    "revision": "fa0f131448623df4896babe350f1dc9d",
    "url": "./static/media/logo.fa0f1314.png"
  },
  {
    "revision": "52eac682e8d399b4a8d1d48e38a60535",
    "url": "./static/media/magnifying-glass.52eac682.svg"
  },
  {
    "revision": "981ecca4e2e244ff635162cbb11b69ac",
    "url": "./static/media/menu.981ecca4.svg"
  },
  {
    "revision": "023762b6aec2a2249b8fdfb638f00ef3",
    "url": "./static/media/metamask.023762b6.png"
  },
  {
    "revision": "17ab2292f09e7d21aa126b0d0cd2f154",
    "url": "./static/media/noise.17ab2292.png"
  },
  {
    "revision": "899a4aa9bf85aba699112cc7cab6578e",
    "url": "./static/media/plus-blue.899a4aa9.svg"
  },
  {
    "revision": "62281ca8cea976c7f20862db5d12728e",
    "url": "./static/media/plus-grey.62281ca8.svg"
  },
  {
    "revision": "b234b2bfa0417c7e8711c3a8d17afeec",
    "url": "./static/media/portisIcon.b234b2bf.png"
  },
  {
    "revision": "1761ff9cb139a2ba2a3a485172eb094c",
    "url": "./static/media/question-mark.1761ff9c.svg"
  },
  {
    "revision": "63be1e247274b62bc269445bf114d497",
    "url": "./static/media/question.63be1e24.svg"
  },
  {
    "revision": "a98424922149274b8a364358d02da9fe",
    "url": "./static/media/spinner.a9842492.svg"
  },
  {
    "revision": "edcc1ab5dde5cb3d5cf134c4aade641b",
    "url": "./static/media/trustWallet.edcc1ab5.png"
  },
  {
    "revision": "5e81cac236fd057cb686399a8fa2ea57",
    "url": "./static/media/walletConnectIcon.5e81cac2.svg"
  },
  {
    "revision": "5b8e218668bfea1d44b887bd042f6a52",
    "url": "./static/media/x.5b8e2186.svg"
  },
  {
    "revision": "ed12c533a5ef9f38e658b16829dff781",
    "url": "./static/media/xl_uni.ed12c533.png"
  }
]);